function y = f1(x)
y = x.^3 - 2.*x;
