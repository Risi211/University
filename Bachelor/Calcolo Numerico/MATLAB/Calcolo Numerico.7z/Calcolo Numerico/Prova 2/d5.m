function y = d5(x)
y = (3 - x)./ 2 - 0.5;