function y = d4(x)
y = 2.*x - 2 - 1./x;