function y = d1(x)
y = 3.*x.^2 - 2;