function y = f6(x)
y = x.^3 - 1.9 * x.^2 - 1.2 * x + 2.5;