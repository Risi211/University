function y = f4(x)
y = x.^2 - 2.*x - log(x);
