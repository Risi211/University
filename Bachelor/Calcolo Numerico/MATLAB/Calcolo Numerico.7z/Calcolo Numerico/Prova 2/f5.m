function y = f5(x)
y = log(2/(3-x));