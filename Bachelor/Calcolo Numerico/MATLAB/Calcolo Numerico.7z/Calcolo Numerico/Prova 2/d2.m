function y = d2(x)
y = x.^2 .* cos(x) - sin(x).*x.^3;