function y = d3(x)
y = x - 1;