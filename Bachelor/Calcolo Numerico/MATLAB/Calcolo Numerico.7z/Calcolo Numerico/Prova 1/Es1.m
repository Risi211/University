
k = 0;
eps = 1/2;
while(1 + eps) > 1
    eps = eps / 2;
    k = k + 1;
end
eps = 2*eps