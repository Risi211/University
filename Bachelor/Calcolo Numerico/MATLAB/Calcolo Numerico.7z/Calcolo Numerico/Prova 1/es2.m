
x = eps:-eps/16:eps/2;
f = ((1 + x) - 1)./x;
figure
plot(x,f,'o');
