function [ x,k,t ] = iterativo(M,N,b,xiniziale,err,tipo)
%k parte da zero
%la x-iniziale � la x ^ k-1, x � la x^k
%inizializzo vettore di output
x = zeros(length(b),1);
%trovo matrice di iterazione
T = M\N;
if (strcmp(tipo,'piene'))
    x = T*xiniziale + M\b;
else
    %trovo i 3 vettori che rappresentano la matrice in formato sparso
    [r,c,i] = vettori_CRS(T);
    %prodotto in forma sparso
    x = (sparsa(r,c,i,xiniziale))' + M\b; %sparsa ritorna il vettore scritto per riga, deve essere scritto per colonna
end

% aggiorno k
k = 1;
%calcolo errore
errore = norm(x - xiniziale);
tic
while(errore > err)
    %eseguo gli stessi passi finch� l'errore � minore dell'errore massimo
    %(err-max)
    %aggiorno il vettore iniziale
    xiniziale = x;
    %calcolo la nuova x^k
    if (strcmp(tipo,'piene'))
        x = T*xiniziale + M\b;
    else
        %trovo i 3 vettori che rappresentano la matrice in formato sparso
        [r,c,i] = vettori_CRS(T);
        %prodotto in forma sparso
        x = (sparsa(r,c,i,xiniziale))' + M\b; %sparsa ritorna il vettore scritto per riga, deve essere scritto per colonna
    end
    %calcolo il nuovo errore
    errore = norm(x - xiniziale);
    %aggiorno k
    k = k + 1;
end
t = toc;   
end