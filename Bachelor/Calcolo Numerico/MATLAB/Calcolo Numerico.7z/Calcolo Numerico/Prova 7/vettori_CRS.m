function [ r,c,i ] = vettori_CRS(A)
[I,J,vals] = find(A'); %A' � la trasposta
r = vals;   %valori non nulli visti per righe
c = I;
temp=(A~=0); %trova elementi non nulli e ci mette 1 (temp � una matrice)
d = sum(temp,2); %trova quanti elementi non nulli sono in una riga (� un vettore)
i = [1;cumsum(d) + 1]; %somma cumulativa
% i(2:end+1) = i; %trasla gli elementi di 1 posizione in avanti
% i(1) = 1;       %il vettore i � completo
end