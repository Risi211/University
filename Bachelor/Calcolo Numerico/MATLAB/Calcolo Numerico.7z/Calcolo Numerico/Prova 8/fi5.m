function y = fi5(x)
y = 3.*x.^3 + 2.*x + 2;
end