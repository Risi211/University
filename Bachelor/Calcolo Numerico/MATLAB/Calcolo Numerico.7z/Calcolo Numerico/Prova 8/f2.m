function y = f2(x)
y = abs(x);
end