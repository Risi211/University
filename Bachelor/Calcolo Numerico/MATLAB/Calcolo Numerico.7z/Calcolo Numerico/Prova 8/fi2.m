function y = fi2(x)
y = 1./(1+x);
end