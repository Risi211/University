function y = fi6(x)
y = exp(1).^x.^2;
end