function y = fi7(x)
y = sin(10.*x);
end