function y = fi4(x)
y = 1./(1 + x.^2);
end