function y = fi3(x)
y = (1 + x)./(1 + x.^3);
end