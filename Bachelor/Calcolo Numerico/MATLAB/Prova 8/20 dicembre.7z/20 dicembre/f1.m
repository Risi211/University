function y = f1(x)
y = 1./(1+25.*x.^2);
end