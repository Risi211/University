function y = fi1(x)
y = 2.^x;
end