function y = f3(x)
y = x ./ (x.^2 + 0.01);
end