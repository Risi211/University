function [ x,k,t ] = gauss_seidel(M,N,b,xiniziale,err)
%k parte da zero
%la x-iniziale � la x ^ k-1, x � la x^k
%inizializzo vettore di output
x = zeros(length(b),1);
%faccio il primo passo
%x = -D\(E*x + F*xiniziale - b);
x = (M\N)*xiniziale + M\b; 
% aggiorno k
k = 1;
%calcolo errore
errore = norm(x - xiniziale);
tic
while(errore > err)
    %eseguo gli stessi passi finch� l'errore � minore dell'errore massimo
    %(err-max)
    %aggiorno il vettore iniziale
    xiniziale = x;
    %calcolo la nuova x^k
    %x = -D\(E*x + F*xiniziale - b);
    x = (M\N)*xiniziale + M\b; 
    %calcolo il nuovo errore
    errore = norm(x - xiniziale);
    %aggiorno k
    k = k + 1;
end
t = toc;   
end