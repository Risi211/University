%[I,J,vals] = find(F')
%c = I
%r = vals

%i = si parte da 1, si fa un vettore in cui si somma tutti gli elementi di

%%temp=(F'==0); trova gli elementi dove gli indici sono diversi da zero e
%%ci mette 1

%d = sum(temp,2);
%i = cumsum(d);
%i(2:end+1) = i;
%i(1) = 1;

%ora ho tutti e 3 i vettori


function [ x,k,t ] = gauss_seidel_sparso(M,N,b,xiniziale,err)
%k parte da zero
%la x-iniziale � la x ^ k-1, x � la x^k
%inizializzo vettore di output
x = zeros(length(b),1);
%faccio il primo passo
%calcolo M\N, diventa T, T in formato sparso, T*x in formato sparso con metodo vecchio
T = M\N;
%trovo i 3 vettori che rappresentano la matrice in formato sparso
[r,c,i] = vettori_CRS(T);
%prodotto in forma sparso
x = sparsa(r,c,i,xiniziale) + M\b;
% aggiorno k
k = 1;
%calcolo errore
errore = norm(x - xiniziale);
tic
while(errore > err)
    %eseguo gli stessi passi finch� l'errore � minore dell'errore massimo
    %(err-max)
    %aggiorno il vettore iniziale
    xiniziale = x;
    %calcolo la nuova x^k
    %prodotto in forma sparso
    x = sparsa(r,c,i,xiniziale) + M\b;
    %calcolo il nuovo errore
    errore = norm(x - xiniziale);
    %aggiorno k
    k = k + 1;
end
t = toc;   
end