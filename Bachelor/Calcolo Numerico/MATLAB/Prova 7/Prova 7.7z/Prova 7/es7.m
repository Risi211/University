function [ x1,c1,r1,k1,t1,x2,c2,r2,k2,t2 ] = es7(n,metodo,tipo)
    x1 = 0;
    c1 = 0;
    r1 = 0;
    k1 = 0;
    t1 = 0;
    x2 = 0;
    c2 = 0;
    r2 = 0;
    k2 = 0;
    t2 = 0;
%matrice 1
[c,d,e]=gallery('dorr',n,0.1);
A1=gallery('tridiag',c,d,e);
A1=full(A1);
%matrice 2
A2 = gallery('frank',n,2);

%Matrice A1
%termine noto = somma delle righe della matrice
b=sum(A1,2); %somma per righe la matrice A1 (la soluzione �: tutte le x = 1)
%errore (criterio di arresto)
err = 1e-6;
%calcolo E,D,F
F = zeros(n,n) + triu(A1,1);  %parte superiore
E = zeros(n,n) + tril(A1,-1); %parte inferiore
D = A1 - triu(A1,1) - tril(A1,-1); %diagonale
%vettore iniziale
xiniziale = zeros(n,1);
%controllo come devo calcolare la matrice di iterazione
if (strcmp(metodo,'jacobi'))
    %JACOBI per matrice 1
    M = D;
    N = -(E+F);
elseif (strcmp(metodo,'gauss_seidel'))
    %GAUSS_SEIDEL per matrice 1
    M = E + D;
    N = -F;
else
    disp('input non valido');
    return
end
T = M\N; %M^(-1)*N, matrice di iterazione
%calcolo raggio spettrale della matrice di iterazione
r1 = max(abs(eig(T))); %eig trova gli autovalori, abs fa il valore assoluto, max prende il massimo dei valori assoluti del raggio spettrale
%calcolo indice di condizionamento della matrice del sistema lineare
c1 = cond(A1);
if (r1 > 1)
    disp('il raggio spettrale della matrice di iterazione del primo sistema � maggiore di 1, quindi il metodo non converge');
    return
end
[x1,k1,t1] = iterativo(M,N,b,xiniziale,err,tipo);

%Matrice A2
%calcolo E,D,F
F = zeros(n,n) + triu(A2,1);  %parte superiore
E = zeros(n,n) + tril(A2,-1); %parte inferiore
D = A2 - triu(A2,1) - tril(A2,-1); %diagonale
%calcolo termine noto = somma delle righe della matrice
b=sum(A2,2); %somma per righe la matrice A1 (la soluzione �: tutte le x = 1)
%vettore iniziale
xiniziale = zeros(n,1);
%controllo come devo calcolare la matrice di iterazione
if (strcmp(metodo,'jacobi'))
    %JACOBI per matrice 1
    %calcolo raggio spettrale della matrice di iterazione
    M = D;
    N = -(E+F);
elseif (strcmp(metodo,'gauss_seidel'))
    %GAUSS_SEIDEL per matrice 1
    M = E + D;
    N = -F;
else
    disp('input non valido');
    return
end
T = M\N; %M^(-1)*N, matrice di iterazione
%calcolo raggio spettrale della matrice di iterazione
r2 = max(abs(eig(T))); %eig trova gli autovalori, abs fa il valore assoluto, max prende il massimo dei valori assoluti del raggio spettrale
%calcolo indice di condizionamento della matrice del sistema lineare
c2 = cond(A2);
if (r2 > 1)
    disp('il raggio spettrale della matrice di iterazione del secondo sistema � maggiore di 1, quindi il metodo non converge');
    return
end
[x2,k2,t2] = iterativo(M,N,b,xiniziale,err,tipo);

end