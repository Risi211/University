function y = f3(x)
y = x.^2 -x + 2;