x(1,1) = 1;
errore = 1e-6;
somma = x(1,1);
cont = 2;
while ((pi - somma) > errore)
    x(1,cont) = (-1)^(cont - 1)*(1/(2*(cont-1) + 1));
    somma = somma + x(1,cont);
    cont = cont + 1;
end
ans = cont - 1