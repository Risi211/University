package pap.lab04.hello;

public class TestHello {

	public static void main(String[] args){
		
		MyThread myThread = new MyThread("Pippo");
		myThread.start();		
		
		String myName = Thread.currentThread().getName();		
		System.out.println("Thread spawned - I'm "+myName);
		
	}
}
