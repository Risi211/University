package lab04.hello;

class MyThread2 extends Thread {

	private String name;
	
	public MyThread2(String myName){
		name= myName;
	}
	/*
	public String getName(){
		
	}
	*/
	
	public void run(){
		System.out.println("Hello concurrent world!");
	}
}

public class TestHello {

	public static void main(String[] args) throws Exception{
		
		MyThread myThread = new MyThread("Pippo");
		myThread.start();		
		
		/*Thread myThr2 = new Thread(()->{
		    System.out.println("hello from paperino");	
		
		});
		myThr2.start();
		*/
		
		String myName = Thread.currentThread().getName();	
		Thread.currentThread().sleep(5000);
		System.out.println("Thread spawned - I'm "+myName);
		
	}
	
}


