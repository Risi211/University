package pap.ass03;

import java.util.List;

public interface ShapeViewer {
	
	void update(List<Shape> shapes);

}
