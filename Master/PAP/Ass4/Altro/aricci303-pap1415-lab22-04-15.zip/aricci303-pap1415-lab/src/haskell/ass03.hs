
-- Corso PAP 2014-2015 - ISI-LM - UNIBO
-- Sorgenti soluzioni Assignment #3

data StarSeq = Star StarSeq | End
            deriving (Show)


-- data una lista di StarSeq computa lunghezza e posizione della sequenza più lunga 
getMaxSeq :: [StarSeq] -> Maybe (Int,Int)
getMaxSeq [] = Nothing 
getMaxSeq xs = Just (maxlun,pos)
	where
		(maxlun,pos,_) = foldl (\(l,p,cp) l1 -> if (l > l1) then (l,p,cp+1) else (l1,cp,cp+1)) 
							(-1,0,0) (map (\s -> lenStarSeq s) xs)

lenStarSeq :: StarSeq -> Int
lenStarSeq End = 0
lenStarSeq (Star s) = 1 + lenStarSeq s

-- data una lista di StarSeq, stampa in uscita le sequenze in ordine crescente di lunghezza, 
-- rappresentandole come sequenze di *, una sequenza per ogni linea
printSeqs :: [StarSeq] -> IO ()
printSeqs xs = foldl (\a s -> (a >> ((printSeq s) >> (putChar '\n')))) (return ()) (sortSeqs xs)

printSeq :: StarSeq -> IO()
printSeq End = return ()
printSeq (Star s) = (putChar '*') >> (printSeq s)

sortSeqs :: [StarSeq] -> [StarSeq]
sortSeqs [] = []
sortSeqs (x:xs) = (sortSeqs ls) ++ (x: sortSeqs rs)
	where 
		ls = [ x1 | x1 <- xs, (lenStarSeq x1) < (lenStarSeq x)];
		rs = [ x2 | x2 <- xs, (lenStarSeq x2) >= (lenStarSeq x)];


-- tests

test_lenStarSeq =
	(lenStarSeq End == 0) && 
	(lenStarSeq (Star (Star End)) == 2)

test_getMaxSeq =
	(getMaxSeq [] == Nothing) &&
	(getMaxSeq [ Star End, End, Star (Star (Star End)), Star End, Star (Star End) ] == Just (3,2)) &&
	(getMaxSeq [ Star End, End, Star (Star (Star End)), Star End, Star (Star (Star End)) ] == Just (3,4))

test_printSeqs =
	printSeqs [ Star End, End, Star (Star End), Star End, Star (Star (Star End))]

test_sortSeqs =
	sortSeqs [End, Star (Star End), Star End, Star (Star (Star End)), Star End]

